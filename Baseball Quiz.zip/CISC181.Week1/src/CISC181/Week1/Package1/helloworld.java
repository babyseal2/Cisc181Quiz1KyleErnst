/**
 * 
 */
package CISC181.Week1.Package1;

/**
 * @author kylee
 *
 */
public class helloworld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
