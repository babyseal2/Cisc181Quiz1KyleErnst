package quiz1baseballstats;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
Scanner L = new Scanner(System.in);		
		Scanner L1 = new Scanner(System.in);
		System.out.println("Enter Player's First Name:");
		String FirstName = L1.nextLine();
		System.out.println("Enter Player's Last Name:");
		String LastName = L1.nextLine();
		System.out.println("How many hits did "+FirstName + " " +LastName+" have?");
		int Hits = L1.nextInt();
		System.out.println("How many times was "+FirstName+" "+LastName+" at bat?");
		int AB = L1.nextInt();
		System.out.println("How many doubles does "+FirstName+" "+LastName+" have?");
		int dbl = L1.nextInt();
		System.out.println("How many triples does "+FirstName+" "+LastName+" have?");
		int trpl = L1.nextInt();
		System.out.println("How many home runs did "+FirstName+" "+LastName+" have?");
		int HR = L1.nextInt();
		System.out.println("How many runs does "+FirstName+" "+LastName+" have?");
		int runs = L1.nextInt();
		System.out.println("How many walks does "+FirstName+" "+LastName+" have?");
		int BB = L1.nextInt();
		System.out.println("What is the HBP");
		int HBP = L1.nextInt();
		Baseballstats Him = new Baseballstats (FirstName, LastName, Hits, AB, BB, HBP, runs, dbl, trpl, HR);
		
		System.out.println("Batting Average: " + Him.BattingAverage());
		System.out.println("On Base Percentage: " + Him.OnBasePercentage());
		System.out.println("Slugging Percentage: " + Him.SluggingPercentage());
		System.out.println("OBS:  " + Him.OnBase());
		System.out.println("Total Bases: " + Him.TotalBases());
	

}

	
	}
